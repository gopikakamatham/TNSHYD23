package com.example.demo.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Admin;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.AdminRepository;

@RestController
@RequestMapping("/api/v1/")
public class AdminController {

	
	@Autowired
	public AdminRepository repo;
	
	
	// create employee rest api
		@PostMapping("/admin")
		public Admin createAdmin(@RequestBody Admin admin) {
			return repo.save(admin);
		}
		
		@GetMapping("/admin")
		public List<Admin> getAllAdmins(){
			return repo.findAll();
		}	
		
		// get employee by id rest api
		@GetMapping("/admin/{id}")
		public ResponseEntity<Admin> getAdminById(@PathVariable Long id) {
			Admin admin = repo.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("Admin not exist with id :" + id));
			return ResponseEntity.ok(admin);
		}
		
		// delete employee rest api
		@DeleteMapping("/admin/{id}")
		public ResponseEntity<Map<String, Boolean>> deleteAdmin(@PathVariable Long id){
			Admin admin = repo.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("Admin not exist with id :" + id));
			
			repo.delete(admin);
			Map<String, Boolean> response = new HashMap<>();
			response.put("deleted", Boolean.TRUE);
			return ResponseEntity.ok(response);
		}
		
		
		@PutMapping("/admin/{id}")
		public ResponseEntity<Admin> updateAdmin(@PathVariable Long id, @RequestBody Admin adminDetails){
		Admin admin = repo.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("Admin not exist with id :" + id));
			
			admin.setName(adminDetails.getName());
			admin.setPassword(adminDetails.getPassword());
			
			Admin updatedAdmin = repo.save(admin);
			return ResponseEntity.ok(updatedAdmin);
		}
		
}
