package P1;
import P3.*;
class B
{
public static void main(String[] args)
{
A obj = new A();
obj.display();
}
}
