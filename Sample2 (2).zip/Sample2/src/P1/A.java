package P1;//protected
public class A
{
protected void display()
{
System.out.println("TNS Sessions");
}
}