package com.day3;

public class A {
	int a=15;
	static int b=20;
	int display() {
		return 1;
	}
		static void display1() {
			System.out.println(10);
		}
	
	public static void main(String[] args) {
		int c=30;
		System.out.println(c);
		A a1=new A();
		System.out.println(a1.a);
		a1.display();
		System.out.println(A.b);
		A.display1();
		
		
	}

}
