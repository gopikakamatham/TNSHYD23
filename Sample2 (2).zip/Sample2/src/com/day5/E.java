package com.day5;// private

 class E {
	 private void display() {
		 System.out.println("TNS session");
	 }
 }
 