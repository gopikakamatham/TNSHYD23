package pack;

public class B {
	public void msg()
	{
	System.out.println("Hello C");
	}

}
