package package1;

	import pack.*;  
	import subpackage.*;
	class C{  
	  public static void main(String args[]){  
	   A obj = new A();  
	   B obj1 = new B(); 
	   D obj2 = new D(); 
	   obj.msg();
	   obj1.msg();   
	   obj2.msg();
	  }  
	}

