package P3;//public
public class A
{
public void display()
{
System.out.println("TNS Sessions");
}
}