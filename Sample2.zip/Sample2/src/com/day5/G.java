package com.day5;//private Approch2

 class G {
	 private void display(){
		 System.out.println("TNS sessions");
		 
	 }

	 public static void main(String[] args) {
		G obj=new G();
		obj.display();
				
	}
 }
