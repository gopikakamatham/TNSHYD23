package com.day5;//private

class F{
	 public static void main(String[] args) {
		E e1=new E();
		e1.display();
	 }
}
