package com.day4;

public class D {
	public static void main(String[] args) {
		int c=30;
		System.out.println(c);
		C c1=new C();
		System.out.println(c1.a);
		c1.display();
		System.out.println(C.b);
		C.display1();
	
		
	}

}
