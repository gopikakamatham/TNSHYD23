package P2;//protected
import P1.*;
public class B extends A
{
public static void main(String[] args)
{
B obj = new B();
obj.display();
}
}
