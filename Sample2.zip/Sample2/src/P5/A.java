package P5;
class A
{
void display()
{
System.out.println("Hello World!");
}
}